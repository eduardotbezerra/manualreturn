# Web chat estilo WhatsAPP JS + CSS

Utilizando como base a interface em html e css disponibilizada por http://www.bypeople.com/sliding-css-chat-bubbles/, estou desenvolvendo o comportamento da interface via JS para que posteriosmente esse chat possa ser implementado.
